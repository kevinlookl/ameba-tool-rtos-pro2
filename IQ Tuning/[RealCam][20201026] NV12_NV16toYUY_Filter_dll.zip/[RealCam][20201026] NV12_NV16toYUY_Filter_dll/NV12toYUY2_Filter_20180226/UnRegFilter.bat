@echo off

REM Check permissions
    echo Administrative permissions required. Detecting permissions...

    net session >nul 2>&1
    if %errorLevel% == 0 (
        echo Success: Administrative permissions confirmed.
	goto Register_L8Filter
    ) else (
        echo Failure: Current permissions inadequate.
	pause >nul
	exit /b 1
    )

:Register_L8Filter
echo Unregistering the NV12toYUY2.dll.
regsvr32.exe /u /s %~dp0/NV12toYUY2.dll
PAUSE